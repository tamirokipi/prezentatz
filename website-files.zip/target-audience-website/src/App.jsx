import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  Users, 
  Target, 
  TrendingUp, 
  Brain, 
  Heart, 
  DollarSign,
  Clock,
  CheckCircle,
  ArrowLeft,
  BarChart3,
  Lightbulb,
  Star,
  Zap,
  Award,
  Rocket
} from 'lucide-react'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('hero')
  const [animatedCounters, setAnimatedCounters] = useState({
    clients: 0,
    consultations: 0,
    leads: 0,
    exposure: 0
  })

  useEffect(() => {
    // Animate counters
    const targets = { clients: 3, consultations: 12, leads: 384, exposure: 5120 }
    const duration = 2000
    const steps = 60
    const stepTime = duration / steps

    Object.keys(targets).forEach(key => {
      let current = 0
      const increment = targets[key] / steps
      const timer = setInterval(() => {
        current += increment
        if (current >= targets[key]) {
          current = targets[key]
          clearInterval(timer)
        }
        setAnimatedCounters(prev => ({ ...prev, [key]: Math.floor(current) }))
      }, stepTime)
    })
  }, [])

  const scrollToSection = (sectionId) => {
    setActiveSection(sectionId)
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' })
  }

  const customerTypes = [
    { title: 'נותני שירותים', icon: Users, description: 'יועצי השקעות, עורכי דין, אדריכלים, מעצבי פנים' },
    { title: 'מנהלי שיווק', icon: Target, description: 'בעלי עסקים פיזיים ואי-קומרס, קבלנים, נדל"ן' },
    { title: 'יוצרי תוכן', icon: Brain, description: 'בלוגרים, משפיענים, בעלי קורסים והכללות' }
  ]

  const painPoints = [
    { title: 'חוסר לקוחות איכותיים', severity: 90, icon: Users },
    { title: 'תמחור גרוע', severity: 85, icon: DollarSign },
    { title: 'מודל עסקי לא נכון', severity: 80, icon: BarChart3 },
    { title: 'חוסר מערכות אוטומטיות', severity: 75, icon: Zap },
    { title: 'תחושת בדידות', severity: 70, icon: Heart }
  ]

  const journeyStages = [
    { 
      id: 1, 
      title: 'חוסר מודעות', 
      description: 'הלקוח עובד קשה אך לא רואה תוצאות',
      conversion: '5-10%',
      icon: Clock
    },
    { 
      id: 2, 
      title: 'מודעות לבעיה', 
      description: 'מבין שיש לו בעיה אך לא יודע את הפתרון',
      conversion: '10-15%',
      icon: Lightbulb
    },
    { 
      id: 3, 
      title: 'מודעות לפתרון', 
      description: 'מבין שיש פתרונות אך לא בחר ספק ספציפי',
      conversion: '10-15%',
      icon: Target
    },
    { 
      id: 4, 
      title: 'מודעות למוצר', 
      description: 'מכיר את הפתרון הספציפי ומעריך אותו',
      conversion: '20-30%',
      icon: Star
    },
    { 
      id: 5, 
      title: 'מוכן לרכישה', 
      description: 'משוכנע שהשירות הוא הפתרון הנכון',
      conversion: '20-30%',
      icon: CheckCircle
    }
  ]

  const touchpoints = [
    { title: 'אינסטגרם', description: 'שיווק אורגני/ממומן', stage: 'כניסה' },
    { title: 'עמוד נחיתה', description: 'לכידת לידים ותיאום פגישות', stage: 'ביניים' },
    { title: 'סדרת אימיילים', description: 'טיפוח לידים אוטומטי', stage: 'ביניים' },
    { title: 'ייעוץ ראשוני', description: 'שיחה קצרה לאפיון ראשוני', stage: 'ביניים' },
    { title: 'שיחת מכירה', description: 'שיחה אישית לסגירת עסקה', stage: 'סגירה' },
    { title: 'שימור לקוחות', description: 'ליווי ומכירות נוספות', stage: 'לאחר מכירה' }
  ]

  const recommendations = [
    { 
      title: 'חיזוק נוכחות כיועץ עסקי', 
      priority: 'גבוה',
      description: 'יצירת תוכן ממוקד ייעוץ עסקי וסיפורי הצלחה',
      icon: Award
    },
    { 
      title: 'השקעה בשיווק ממומן', 
      priority: 'גבוה',
      description: 'הגדלת תקציב השיווק הממומן ליצירת לידים',
      icon: TrendingUp
    },
    { 
      title: 'בניית מערכת אוטומציה', 
      priority: 'בינוני',
      description: 'הטמעת מערכות אוטומטיות לטיפוח לידים',
      icon: Zap
    },
    { 
      title: 'פיתוח מוצרים משלימים', 
      priority: 'בינוני',
      description: 'יצירת שירותים ומוצרים נוספים',
      icon: Rocket
    }
  ]

  return (
    <div className="min-h-screen hero-gradient">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold gold-text">ניתוח קהל יעד</h1>
            <div className="hidden md:flex space-x-reverse space-x-6">
              {[
                { id: 'hero', label: 'בית' },
                { id: 'icp', label: 'פרופיל לקוח' },
                { id: 'pains', label: 'כאבים' },
                { id: 'journey', label: 'מסע הלקוח' },
                { id: 'touchpoints', label: 'נקודות מגע' },
                { id: 'metrics', label: 'יעדי המרה' },
                { id: 'recommendations', label: 'המלצות' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`nav-link px-3 py-2 text-sm ${
                    activeSection === item.id ? 'text-primary' : 'text-foreground'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="section-padding pt-24 text-center">
        <div className="container mx-auto max-w-4xl">
          <div className="animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 gold-text">
              ניתוח קהל יעד
            </h1>
            <h2 className="text-2xl md:text-3xl mb-8 text-white/90">
              מהלך מנצח לבניית אסטרטגיית שיווק מותאמת
            </h2>
            <p className="text-lg md:text-xl mb-12 text-white/80 max-w-2xl mx-auto">
              מצגת אינטרקטיבית ודינמית המציגה ניתוח מקיף של קהל היעד, 
              מסע הלקוח ואסטרטגיות שיווק מותאמות לעסקים מצליחים
            </p>
            <Button 
              onClick={() => scrollToSection('icp')}
              className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg px-8 py-3"
            >
              התחל את המסע
              <ArrowLeft className="mr-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* ICP Section */}
      <section id="icp" className="section-padding">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 gold-text">פרופיל הלקוח האידיאלי</h2>
            <p className="text-xl text-white/80">הכרת קהל היעד המושלם לעסק שלך</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <Card className="card-hover animate-slide-in-right">
              <CardHeader>
                <CardTitle className="gold-text flex items-center">
                  <Users className="ml-2 h-6 w-6" />
                  דמוגרפיה
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-primary mb-2">גיל:</h4>
                  <p>19-40 (נותני שירותים), לא מוגדר ספציפית (מנהלי שיווק)</p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">הכנסה:</h4>
                  <p>25-50 אלף ש"ח לחודש (נותני שירותים)<br/>3+ מיליון ש"ח שנתי (מנהלי שיווק)</p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">מיקום:</h4>
                  <p>ישראל (התמקדות בשוק הישראלי)</p>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover animate-slide-in-left">
              <CardHeader>
                <CardTitle className="gold-text flex items-center">
                  <Brain className="ml-2 h-6 w-6" />
                  פסיכוגרפיה
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-primary mb-2">ערכים:</h4>
                  <p>חופש כלכלי ועסקי, הגשמה עצמית, בטחון, שליטה, יעילות</p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">מטרות:</h4>
                  <p>הגדלת רווחיות, גיוס לקוחות איכותיים, בניית מותג חזק</p>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-2">אישיות:</h4>
                  <p>פרואקטיביים, מחפשי פתרונות, פתוחים לשינוי</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {customerTypes.map((type, index) => (
              <Card key={index} className="card-hover text-center">
                <CardHeader>
                  <type.icon className="h-12 w-12 mx-auto text-primary mb-4 floating-icon" />
                  <CardTitle className="gold-text">{type.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80">{type.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pains Section */}
      <section id="pains" className="section-padding bg-black/20">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 gold-text">כאבים ואתגרים</h2>
            <p className="text-xl text-white/80">הבעיות העיקריות שהלקוחות מתמודדים איתן</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {painPoints.map((pain, index) => (
              <Card key={index} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <pain.icon className="h-8 w-8 text-primary ml-3" />
                    <h3 className="text-xl font-semibold">{pain.title}</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>עוצמת הכאב</span>
                      <span>{pain.severity}%</span>
                    </div>
                    <Progress 
                      value={pain.severity} 
                      className="h-2"
                      style={{'--progress-width': `${pain.severity}%`}}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="gold-text text-center">ביטויי הכאב</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-primary mb-3">תסמינים נפוצים:</h4>
                  <ul className="space-y-2 text-white/80">
                    <li>• העסק לא מכניס מספיק כסף או המחזור יורד</li>
                    <li>• עובד קשה אך לא מתקדם</li>
                    <li>• לקוחות לא מרוצים או עוזבים</li>
                    <li>• שריפת תקציב על פרסום ללא תוצאות</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-3">השפעות נוספות:</h4>
                  <ul className="space-y-2 text-white/80">
                    <li>• חוסר זמן לעסוק בפיתוח העסק או בשיווק</li>
                    <li>• תחושת בדידות בקבלת החלטות עסקיות</li>
                    <li>• פחד מאובדן שליטה והעדר מערכות מסודרים</li>
                    <li>• קושי בגיוס עובדים איכותיים</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Customer Journey */}
      <section id="journey" className="section-padding">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 gold-text">מסע הלקוח</h2>
            <p className="text-xl text-white/80">חמשת השלבים במסע הלקוח מחוסר מודעות לרכישה</p>
          </div>

          <div className="relative">
            <div className="timeline-line absolute top-1/2 right-0 left-0 h-1 transform -translate-y-1/2"></div>
            <div className="grid md:grid-cols-5 gap-4">
              {journeyStages.map((stage, index) => (
                <Card key={stage.id} className="card-hover relative z-10">
                  <CardHeader className="text-center">
                    <div className="mx-auto mb-4 p-3 bg-primary rounded-full w-fit">
                      <stage.icon className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-lg gold-text">{stage.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-sm text-white/80 mb-4">{stage.description}</p>
                    <Badge variant="secondary" className="bg-primary/20 text-primary">
                      המרה: {stage.conversion}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Touchpoints */}
      <section id="touchpoints" className="section-padding funnel-section">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 gold-text">נקודות מגע בתוך המשפך</h2>
            <p className="text-xl text-white/80">המסלול המלא מחשיפה ראשונה ועד לקוח נאמן</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {touchpoints.map((touchpoint, index) => (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="gold-text">{touchpoint.title}</CardTitle>
                    <Badge variant="outline" className="border-primary text-primary">
                      {touchpoint.stage}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80">{touchpoint.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Metrics */}
      <section id="metrics" className="section-padding">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 gold-text">יעדי המרה לחודש</h2>
            <p className="text-xl text-white/80">חישוב לאחור ממטרת 3 לקוחות חדשים לחודש</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <Card className="metric-card text-center">
              <CardContent className="p-6">
                <TrendingUp className="h-12 w-12 mx-auto text-primary mb-4" />
                <div className="text-3xl font-bold gold-text mb-2">
                  {animatedCounters.clients}
                </div>
                <p className="text-white/80">לקוחות חדשים</p>
              </CardContent>
            </Card>

            <Card className="metric-card text-center">
              <CardContent className="p-6">
                <Users className="h-12 w-12 mx-auto text-primary mb-4" />
                <div className="text-3xl font-bold gold-text mb-2">
                  {animatedCounters.consultations}
                </div>
                <p className="text-white/80">שיחות ייעוץ</p>
              </CardContent>
            </Card>

            <Card className="metric-card text-center">
              <CardContent className="p-6">
                <Target className="h-12 w-12 mx-auto text-primary mb-4" />
                <div className="text-3xl font-bold gold-text mb-2">
                  {animatedCounters.leads}
                </div>
                <p className="text-white/80">לידים מחוממים</p>
              </CardContent>
            </Card>

            <Card className="metric-card text-center">
              <CardContent className="p-6">
                <BarChart3 className="h-12 w-12 mx-auto text-primary mb-4" />
                <div className="text-3xl font-bold gold-text mb-2">
                  {animatedCounters.exposure.toLocaleString()}
                </div>
                <p className="text-white/80">חשיפות באינסטגרם</p>
              </CardContent>
            </Card>
          </div>

          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="gold-text text-center">שיעורי המרה לפי שלב</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { stage: 'אינסטגרם → עמוד נחיתה', rate: '7.5%' },
                  { stage: 'עמוד נחיתה → ייעוץ ראשוני', rate: '12.5%' },
                  { stage: 'ייעוץ ראשוני → שיחת מכירה', rate: '25%' },
                  { stage: 'שיחת מכירה → רכישה', rate: '25%' }
                ].map((item, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                    <span className="text-white/90">{item.stage}</span>
                    <Badge variant="secondary" className="bg-primary/20 text-primary">
                      {item.rate}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Recommendations */}
      <section id="recommendations" className="section-padding bg-black/20">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 gold-text">המלצות אסטרטגיות</h2>
            <p className="text-xl text-white/80">צעדים מעשיים ליישום האסטרטגיה</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {recommendations.map((rec, index) => (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <rec.icon className="h-8 w-8 text-primary ml-3" />
                      <CardTitle className="gold-text">{rec.title}</CardTitle>
                    </div>
                    <Badge 
                      variant={rec.priority === 'גבוה' ? 'destructive' : 'secondary'}
                      className={rec.priority === 'גבוה' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}
                    >
                      {rec.priority}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80">{rec.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="card-hover mt-12">
            <CardHeader>
              <CardTitle className="gold-text text-center">הזדמנויות נוספות</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <Award className="h-12 w-12 mx-auto text-primary mb-4" />
                  <h4 className="font-semibold text-primary mb-2">ניצול ניסיון קיים</h4>
                  <p className="text-sm text-white/80">ניסיון מוכח בהקמת עסקים וליווי עסקים קיימים</p>
                </div>
                <div className="text-center">
                  <Zap className="h-12 w-12 mx-auto text-primary mb-4" />
                  <h4 className="font-semibold text-primary mb-2">שילוב אסטרטגיה וביצוע</h4>
                  <p className="text-sm text-white/80">יכולת לספק גם ייעוץ אסטרטגי וגם פתרונות ביצועיים</p>
                </div>
                <div className="text-center">
                  <Users className="h-12 w-12 mx-auto text-primary mb-4" />
                  <h4 className="font-semibold text-primary mb-2">בניית קהילה</h4>
                  <p className="text-sm text-white/80">יצירת קהילה סביב המותג לחיזוק האמון</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="section-padding border-t border-border">
        <div className="container mx-auto max-w-6xl text-center">
          <h3 className="text-2xl font-bold gold-text mb-4">ניתוח קהל יעד - מהלך מנצח</h3>
          <p className="text-white/80 mb-8">
            מצגת אינטרקטיבית לבניית אסטרטגיית שיווק מותאמת ומנצחת
          </p>
          <div className="flex justify-center space-x-reverse space-x-4">
            <Button 
              onClick={() => scrollToSection('hero')}
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              חזרה לראש הדף
            </Button>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

